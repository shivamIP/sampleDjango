from django.contrib import admin
from index.models import Applicant

admin.site.register(Applicant)

# Register your models here.
